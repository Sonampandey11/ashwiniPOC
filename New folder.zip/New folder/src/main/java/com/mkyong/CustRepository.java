package com.mkyong;


import org.springframework.data.jpa.repository.JpaRepository;

public interface CustRepository extends JpaRepository<Customer, Integer>{

	/*@Query("select new com.mkyong.CustomerValue(id,name,address,phone) FROM Customer")
	public List<CustomerValue> getCustomer(@Param("id") int id);*/
}
