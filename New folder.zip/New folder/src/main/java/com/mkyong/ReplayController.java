package com.mkyong;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class ReplayController {

	@Autowired
	CustomerImplService customerImplService;
	
	@RequestMapping("/view")
	public String view(ModelMap model) {
		List<ReplayValue> RList = customerImplService.getPayloadRecords();
		model.put("payloadRecords", RList);
		return "ViewReplayPayload";
	}
	
	@RequestMapping(value="/send" , method = RequestMethod.POST)
	public void playReplayQueue(List<ReplayValue> RList) {
		String queue = RList.get(0).getQueue();
		Object cust = RList.get(0).getPayload();
		Customer cu = (Customer) cust;
		customerImplService.send(queue, cu);
	}
}