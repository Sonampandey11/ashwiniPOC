package com.mkyong;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ReplayRepository extends JpaRepository<Replay, Integer> {

	@Query("select new com.mkyong.ReplayValue(id,payload,queue,replay_queue) FROM Replay")
	public List<ReplayValue> getErrorLog();
}
