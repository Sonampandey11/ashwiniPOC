package com.mkyong;

public class ReplayValue {

	private Integer id;
	private String payload;
	private String queue;
	private String replay_queue;

	public ReplayValue(Integer id, String payload, String queue, String replay_queue) {
		this.id = id;
		this.payload = payload;
		this.queue = queue;
		this.replay_queue = replay_queue;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getQueue() {
		return queue;
	}

	public void setQueue(String queue) {
		this.queue = queue;
	}

	public String getReplay_queue() {
		return replay_queue;
	}

	public void setReplay_queue(String replay_queue) {
		this.replay_queue = replay_queue;
	}

	public String toString() 
    { 
        return id + " " + payload + " " + queue ; 
    } 
}
