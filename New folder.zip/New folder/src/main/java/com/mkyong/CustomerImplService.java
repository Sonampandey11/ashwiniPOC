package com.mkyong;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class CustomerImplService implements CustomerService {

	@Autowired
	CustRepository custRepository;

	@Autowired
	ReplayRepository replayRepository;

	@Autowired
	JmsTemplate jmsTemplate;

	public Customer getCustomerObject(int id) {
		return custRepository.findById(id).get();
	}

	public void send(String topic, Customer cust) {
		jmsTemplate.convertAndSend("PocReplaytopic", cust, message -> {
			return message;
		});
	}

	@Override
	@Transactional
	public List<ReplayValue> getPayloadRecords() {
		List<ReplayValue> RList = replayRepository.getErrorLog();
		return RList;
	}
}
