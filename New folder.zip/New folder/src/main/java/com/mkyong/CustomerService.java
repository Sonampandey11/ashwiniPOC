package com.mkyong;

import java.util.List;

public interface CustomerService {

	public List<ReplayValue> getPayloadRecords();
}
